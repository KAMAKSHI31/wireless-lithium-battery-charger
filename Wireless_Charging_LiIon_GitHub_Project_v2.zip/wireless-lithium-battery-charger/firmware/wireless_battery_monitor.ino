/*
  Wireless Lithium-Ion Battery Charging System - Monitoring Firmware
  Board: ESP32
  Sensors: INA219 + DS18B20

  IMPORTANT:
  - This sketch is for monitoring only.
  - It does NOT control or replace the Li-ion charger or battery protection.
  - Use a correctly selected 1S CC/CV charger and a protected cell.
  - Verify all module pinouts and voltage levels before powering the circuit.
*/

#include <Wire.h>
#include <Adafruit_INA219.h>
#include <OneWire.h>
#include <DallasTemperature.h>

constexpr int I2C_SDA_PIN = 21;
constexpr int I2C_SCL_PIN = 22;
constexpr int ONE_WIRE_PIN = 4;

// Set this to the maximum temperature allowed by the datasheets
// for your exact cell and charger. This is only a warning threshold.
constexpr float TEMP_WARNING_C = 40.0;

Adafruit_INA219 ina219;
OneWire oneWire(ONE_WIRE_PIN);
DallasTemperature temperatureSensor(&oneWire);

bool ina219Ready = false;

void setup() {
  Serial.begin(115200);
  delay(500);

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  temperatureSensor.begin();

  ina219Ready = ina219.begin();

  Serial.println();
  Serial.println("Wireless Li-ion Battery Monitor");
  Serial.println("--------------------------------");

  if (!ina219Ready) {
    Serial.println("ERROR: INA219 not detected. Check SDA, SCL, VCC and GND.");
  } else {
    // Default INA219 calibration is suitable for many basic breakout
    // demonstrations. Confirm the module/shunt rating for your hardware.
    Serial.println("INA219 detected.");
  }

  Serial.print("DS18B20 devices found: ");
  Serial.println(temperatureSensor.getDeviceCount());
}

void loop() {
  if (ina219Ready) {
    float busVoltage_V = ina219.getBusVoltage_V();
    float shuntVoltage_mV = ina219.getShuntVoltage_mV();
    float current_mA = ina219.getCurrent_mA();
    float power_mW = ina219.getPower_mW();

    Serial.println();
    Serial.println("Battery electrical measurements");
    Serial.print("Bus voltage: ");
    Serial.print(busVoltage_V, 3);
    Serial.println(" V");

    Serial.print("Shunt voltage: ");
    Serial.print(shuntVoltage_mV, 3);
    Serial.println(" mV");

    Serial.print("Current: ");
    Serial.print(current_mA, 2);
    Serial.println(" mA");

    Serial.print("Power: ");
    Serial.print(power_mW, 2);
    Serial.println(" mW");
  }

  temperatureSensor.requestTemperatures();
  float temperatureC = temperatureSensor.getTempCByIndex(0);

  Serial.println("Temperature measurement");
  if (temperatureC == DEVICE_DISCONNECTED_C) {
    Serial.println("DS18B20 not detected. Check sensor wiring and 4.7k pull-up.");
  } else {
    Serial.print("Cell surface temperature: ");
    Serial.print(temperatureC, 2);
    Serial.println(" °C");

    if (temperatureC >= TEMP_WARNING_C) {
      Serial.println("WARNING: Temperature reached the configured warning threshold.");
      Serial.println("Stop charging safely and inspect the setup.");
    }
  }

  Serial.println("--------------------------------");
  delay(2000);
}
