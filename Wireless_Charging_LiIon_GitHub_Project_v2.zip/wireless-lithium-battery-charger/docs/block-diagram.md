# Block Diagram

```text
Regulated 5 V supply
        |
        v
Qi transmitter  )))))  Qi receiver
                         |
                         v
                  Regulated DC output
                         |
                         v
                  1S Li-ion CC/CV charger
                         |
                         v
                    INA219 shunt
                         |
                         v
                 Protected 1S Li-ion cell

INA219 SDA/SCL ----------------> ESP32
DS18B20 DATA ------------------> ESP32
ESP32 USB Serial --------------> Laptop / Serial Monitor
```

The ESP32 monitors the system. The dedicated charger and cell protection hardware perform charging and protection functions.
