# Wiring checklist

## Qi and charger power path
- Qi receiver regulated output positive -> charger input positive.
- Qi receiver ground -> charger input negative.
- Charger BAT+ -> INA219 VIN+.
- INA219 VIN- -> protected cell positive.
- Charger BAT- -> protected cell negative.

## INA219 to ESP32
- VCC -> 3V3
- GND -> GND
- SDA -> GPIO 21
- SCL -> GPIO 22

## DS18B20 to ESP32
- VDD -> 3V3
- GND -> GND
- DATA -> GPIO 4
- 4.7 kΩ resistor between DATA and 3V3.

Check the exact pin labels and datasheets for the modules in hand. Do not assume all breakouts have identical layouts.
