# Test Plan and Results

## Pre-power checks
- [ ] Confirm the Qi receiver output rating and charger input rating are compatible.
- [ ] Confirm the charger is for one 4.2 V Li-ion cell.
- [ ] Confirm the charger current setting is within the cell datasheet limit.
- [ ] Confirm the cell is protected, undamaged, and correctly polarized.
- [ ] Inspect wiring and check for shorts with a multimeter.

## Functional tests
- [ ] Measure Qi receiver output with the battery disconnected.
- [ ] Upload the ESP32 firmware and confirm INA219 detection.
- [ ] Confirm DS18B20 temperature readings.
- [ ] Connect the protected cell only after the charger and wiring have been verified.
- [ ] Observe charging current and cell surface temperature under supervision.
- [ ] Repeat with different coil alignments and document measured results.

## Results log

| Trial | Alignment / gap | Receiver voltage (V) | Charge current (mA) | Temperature (°C) | Notes |
|---|---|---:|---:|---:|---|
| 1 | Centered | | | | |
| 2 | Slight offset | | | | |
| 3 | Larger offset | | | | |

Enter only measured results. Stop immediately if the cell becomes unusually hot, swells, leaks, smells, or behaves abnormally.
